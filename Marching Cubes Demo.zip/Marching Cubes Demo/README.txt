Controls:
Z - show/unshow cursor
Spacebar - to reset camera position in case you get lost in the abyss